#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
*
*@author h30002440
*@version [eService  3.0.15, ${DATE}]
*@since ${DATE}
*/
public @interface ${NAME} {
}
