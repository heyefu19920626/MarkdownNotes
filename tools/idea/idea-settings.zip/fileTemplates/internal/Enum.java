#parse("File Header.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

/**
*
*@author h30002440
*@version [eService  3.0.10, 2020-4-15]
*@since ${DATE}
*/
public enum ${NAME} {
}
